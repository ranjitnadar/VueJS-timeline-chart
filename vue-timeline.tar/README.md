# vue-project

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```


### Note
```
List of library used to build d3 timline
    - d3 version 3.5
    - d3-tip version 0.6
    - For now using hard-coded data passing to component, i can send another set of code which contain ajax request for data pull.