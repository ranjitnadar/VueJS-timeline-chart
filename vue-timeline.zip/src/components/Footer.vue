<template>
   <footer class="footer">
        <p>&copy; Company 2017</p>
      </footer>
</template>
<script>
export default {
  name: "footer",
  data() {
    return {};
  },
  methods: {}
};
</script>
<style>

.footer {
  padding: 1.2em 0em;
  margin-top: 2em;
  border-top: 1px solid #eee;
}

</style>
